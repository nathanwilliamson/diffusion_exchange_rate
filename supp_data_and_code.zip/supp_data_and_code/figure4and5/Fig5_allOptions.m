%close all
clear all
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% load and prepare data


load('SpinalCord_Fixed_20181214_tmMax1000.mat')

%% Initialize figure.

COLORS = 1/255 * [  55  80  162 ; ...
    93  187 70  ; ...
    241 156 31  ; ...
    237 28  36  ; ...
    129 41  134 ];
COLORSpatch = 1/255 * [255 255 100  ; ...
    100 255 100  ; ...
    150 255 255];

col=get(groot,'DefaultAxesColorOrder');
fig                 = figure();
fig.Units           = 'centimeters';
fig.PaperUnits      = 'centimeters';
fig.Position        = [0 0 8 7.5];
fig.PaperPosition   = fig.Position;



FontName            = 'helvetica';
FontSize            = 7;
FontWeight          = 'normal';

 
%% Plot attenuation and fits
h                   = axes();
h.Units             = 'centimeters';
h.FontName          = FontName;
h.FontSize          = FontSize;
h.FontWeight        = FontWeight;
h.Position          = [1.25 4.75 6 2.5];
%h.YTick             = [.1 .2];
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
h.XLabel.String     = '$ t_m$ [ms]';
h.YLabel.String     = '$I/I_0$';
h.YScale            = 'log';
%h.XLim(2)           = 3.5;
h.YLim           = [0 1];

h.YLabel.Units      = 'centimeters';
h.YLabel.Position(1) = -0.8;

%h.YMinorTick = 'on';
h.XMinorTick = 'on';
h.TickLength = [.02 .02] ;
h.TickDir    = 'out';
h.Box               = 'off';

hold on

 %% I_3/I_1
MixingTimelist=S.MixingTimelist';
clear Imean
clear Istd
Imean=mean(S.T.I_3./S.T.I_1,1)';
Istd=std(S.T.I_3./S.T.I_1,0,1)';
Istd=Istd/Imean(1);
Imean=Imean/Imean(1);
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

 hf = patch(bpatch,Ipatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORS(1,:);
 hf.FaceAlpha = .6;

hl = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl.Marker = 's';
hl.MarkerFaceColor=COLORS(1,:);
   hl.LineStyle = 'none';
 hl.MarkerSize = 3;
 hl.Color = COLORS(1,:)/2;

%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + mean(S.T.baseline_I3);
% theory=theory/mean(S.T.I_1(:,1))
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];

% BL=mean(mean(S.T.I_AXR_I3(:,44:end)));
% load('SpinalCord_Fixed_20181214_tmMax1000_BaselineSubtract.mat')
% 
%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + BL;
% theory=theory/mean(S.T.I_1(:,1));
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];

%% I_3/I_2
MixingTimelist=S.MixingTimelist';
Imean=mean(S.T.I_3./S.T.I_2,1)';
Istd=std(S.T.I_3./S.T.I_2,0,1)';
Istd=Istd/Imean(1);
Imean=Imean/Imean(1);
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

 hf = patch(bpatch,Ipatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORS(3,:);
 hf.FaceAlpha = .6;

hl = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl.Marker = 'o';
hl.MarkerFaceColor=COLORS(3,:);
   hl.LineStyle = 'none';
 hl.MarkerSize = 3;
 hl.Color = [0.3 0.3 0.3];

%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + mean(S.T.baseline_I3);
% theory=theory/mean(S.T.I_1(:,1))
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];

% BL=mean(mean(S.T.I_AXR_I3(:,44:end)));
% load('SpinalCord_Fixed_20181214_tmMax1000_BaselineSubtract.mat')
% 
%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + BL;
% theory=theory/mean(S.T.I_1(:,1));
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];
%% I_3/exp(-R1*t)
MixingTimelist=S.MixingTimelist';
Imean=mean(S.T.I_AXR_I3,1)';
Istd=std(S.T.I_AXR_I3,0,1)';
Istd=Istd/Imean(1);
Imean=Imean/Imean(1);
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

 hf = patch(bpatch,Ipatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORS(2,:);
 hf.FaceAlpha = .6;

hl3 = scatter(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl3.Marker = '.';
hl3.MarkerFaceColor=COLORS(2,:);
%   hl3.LineStyle = 'none';
% hl3.SizeData = 3;
 hl3.MarkerEdgeColor = [0 0 0];%COLORS(2,:)/2;
  hl3.MarkerFaceAlpha=0.5;
    hl3.MarkerEdgeAlpha=0.5;

%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + mean(S.T.baseline_I3);
% theory=theory/mean(S.T.I_1(:,1))
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];

% BL=mean(mean(S.T.I_AXR_I3(:,44:end)));
% load('SpinalCord_Fixed_20181214_tmMax1000_BaselineSubtract.mat')
% 
%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + BL;
% theory=theory/mean(S.T.I_1(:,1));
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];
%% Plot attenuation and fits, zoom
h                   = axes();
h.Units             = 'centimeters';
h.FontName          = FontName;
h.FontSize          = FontSize;
h.FontWeight        = FontWeight;
h.Position          = [1.25 1.25 6 2.5];
%h.YTick             = [.1 .2];
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
h.XLabel.String     = '$ t_m$ [ms]';
h.YLabel.String     = '$I/I_0$';
%h.YScale            = 'log';
h.XLim(2)           = 100;
h.YLim           = [.67 1];

h.YLabel.Units      = 'centimeters';
h.YLabel.Position(1) = -0.8;

%h.YMinorTick = 'on';
h.XMinorTick = 'on';
h.TickLength = [.02 .02] ;
h.TickDir    = 'out';
h.Box               = 'off';

hold on


 %% I_3/I_1
MixingTimelist=S.MixingTimelist';
clear Imean
clear Istd
Imean=mean(S.T.I_3./S.T.I_1,1)';
Istd=std(S.T.I_3./S.T.I_1,0,1)';
Istd=Istd/Imean(1);
Imean=Imean/Imean(1);
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

 hf = patch(bpatch,Ipatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORS(1,:);
 hf.FaceAlpha = .6;

hl1 = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl1.Marker = 's';
hl1.MarkerFaceColor=COLORS(1,:);
   hl1.LineStyle = 'none';
 hl1.MarkerSize = 3;
 hl1.Color = COLORS(1,:)/2;
 hl1.DisplayName='$I_{pt3}/I_{pt1}$'


%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + mean(S.T.baseline_I3);
% theory=theory/mean(S.T.I_1(:,1))
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];

% BL=mean(mean(S.T.I_AXR_I3(:,44:end)));
% load('SpinalCord_Fixed_20181214_tmMax1000_BaselineSubtract.mat')
% 
%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + BL;
% theory=theory/mean(S.T.I_1(:,1));
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];

%% I_3/I_2
MixingTimelist=S.MixingTimelist';
Imean=mean(S.T.I_3./S.T.I_2,1)';
Istd=std(S.T.I_3./S.T.I_2,0,1)';
Istd=Istd/Imean(1);
Imean=Imean/Imean(1);
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

 hf = patch(bpatch,Ipatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORS(3,:);
 hf.FaceAlpha = .6;

hl2 = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl2.Marker = 'o';
hl2.MarkerFaceColor=COLORS(3,:);
   hl2.LineStyle = 'none';
 hl2.MarkerSize = 3;
 hl2.Color = [0.3 0.3 0.3];
  hl2.DisplayName='$I_{pt3}/I_{pt2}$'


%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + mean(S.T.baseline_I3);
% theory=theory/mean(S.T.I_1(:,1))
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];

% BL=mean(mean(S.T.I_AXR_I3(:,44:end)));
% load('SpinalCord_Fixed_20181214_tmMax1000_BaselineSubtract.mat')
% 
%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + BL;
% theory=theory/mean(S.T.I_1(:,1));
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];
%% I_3/exp(-R1*t)
MixingTimelist=S.MixingTimelist';
Imean=mean(S.T.I_AXR_I3,1)';
Istd=std(S.T.I_AXR_I3,0,1)';
Istd=Istd/Imean(1);
Imean=Imean/Imean(1);
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

 hf = patch(bpatch,Ipatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORS(2,:);
 hf.FaceAlpha = .6;

hl3 = scatter(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl3.Marker = '.';
hl3.MarkerFaceColor=COLORS(2,:);
%   hl3.LineStyle = 'none';
% hl3.SizeData = 3;
 hl3.MarkerEdgeColor = [0 0 0];%COLORS(2,:)/2;
  hl3.DisplayName='$I_{pt3}/\exp(-t_mR_1)$';
  hl3.MarkerFaceAlpha=0.5;
    hl3.MarkerEdgeAlpha=0.5;

%alpha(hl3,0.6);

%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + mean(S.T.baseline_I3);
% theory=theory/mean(S.T.I_1(:,1))
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];

% BL=mean(mean(S.T.I_AXR_I3(:,44:end)));
% load('SpinalCord_Fixed_20181214_tmMax1000_BaselineSubtract.mat')
% 
%  theory=mean(S.T.I0_I3)*exp(-MixingTimelist*mean(S.T.AXR_I3)) + BL;
% theory=theory/mean(S.T.I_1(:,1));
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];

 legend([hl1 hl2 hl3],'Box','off')


fig.Renderer='painters';

%% Save figure.
print(fig,'williamson_fig5.eps','-depsc')
print(fig,'williamson_fig5.png','-dpng','-r2048')
print(fig,'williamson_fig5.tif','-dtiff','-r2048')


