close all
clear all
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% load and prepare data


load('SpinalCord_Fixed_20181214_tmMax1000.mat')

%% Initialize figure.

COLORS = 1/255 * [  55  80  162 ; ...
    93  187 70  ; ...
    241 156 31  ; ...
    237 28  36  ; ...
    129 41  134 ];
COLORSpatch = 1/255 * [255 255 100  ; ...
    100 255 100  ; ...
    150 255 255];

col=get(groot,'DefaultAxesColorOrder');
fig                 = figure();
fig.Units           = 'centimeters';
fig.PaperUnits      = 'centimeters';
fig.Position        = [0 0 8 7.5];
fig.PaperPosition   = fig.Position;



FontName            = 'helvetica';
FontSize            = 7;
FontWeight          = 'normal';

 
%% Plot attenuation and fits
h                   = axes();
h.Units             = 'centimeters';
h.FontName          = FontName;
h.FontSize          = FontSize;
h.FontWeight        = FontWeight;
h.Position          = [1.25 4.75 6 2.5];
h.YTick             = [.01 .1 1];
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
h.XLabel.String     = '$ t_m$ [ms]';
h.YLabel.String     = '$I/I_0$';
h.YScale            = 'log';
%h.XLim(2)           = 3.5;
h.YLim           = [.01 1];

h.YLabel.Units      = 'centimeters';
h.YLabel.Position(1) = -0.8;

h.YMinorTick = 'on';
h.XMinorTick = 'on';
h.TickLength = [.02 .02] ;
h.TickDir    = 'out';
h.Box               = 'off';

hold on

%% I_1
normfac=mean(S.T.I_1(:,1));
MixingTimelist=S.MixingTimelist';
Imean=mean(S.T.I_1,1)';
Istd=std(S.T.I_1,0,1)';
Imean=Imean/normfac;
Istd=Istd/normfac;

Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end
bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(1,:);
%  hf.FaceAlpha = .5;

hl1 = line(MixingTimelist,Imean);%/Imean(1)
% hl.LineStyle = 'none';
 hl1.Marker = 'o';
  hl1.LineStyle = 'none';
  hl1.MarkerFaceColor=COLORS(1,:);
 hl1.MarkerSize = 3;
 hl1.Color = [0.8 0.8 0.8];
 hl1.DisplayName='$I_{pt1}$'


theory=mean(S.T.I0_T1app1)*exp(-MixingTimelist*mean(S.T.AXR_T1app1));
theory=theory/normfac
hl = line(MixingTimelist,theory);%/Imean(1)
 hl.LineStyle = '-';
 hl.Color = [0 0 0];
 
 %% I_2

Imean=mean(S.T.I_2,1)';
Istd=std(S.T.I_2,0,1)';
Imean=Imean/normfac;
Istd=Istd/normfac;
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(5,:);
%  hf.FaceAlpha = .6;

hl2 = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl2.Marker = 'o';
hl2.MarkerFaceColor=COLORS(5,:);
   hl2.LineStyle = 'none';
 hl2.MarkerSize = 7;
 hl2.Color = [0 0 0];
  hl2.DisplayName='$I_{pt2}$'

 
%  theory=mean(S.T.I0_T1app2)*exp(-MixingTimelist*mean(S.T.AXR_T1app2));
% theory=theory/normfac
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];
 
 %% I_3

Imean=mean(S.T.I_3,1)';
Istd=std(S.T.I_3,0,1)';
Imean=Imean/normfac;
Istd=Istd/normfac;
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(3,:);
%  hf.FaceAlpha = .6;

hl3 = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl3.Marker = 'o';
hl3.MarkerFaceColor=COLORS(3,:);
   hl3.LineStyle = 'none';
 hl3.MarkerSize = 3;
 hl3.Color = [0.3 0.3 0.3];
  hl3.DisplayName='$I_{pt3}$'

 
 load('SpinalCord_Fixed_20181214_tmMin100Max1000.mat')
 MixingTimelist=S.MixingTimelist';
normfac=mean(S.T.I_1(:,1));
 theory=mean(S.T.I0_T1app3)*exp(-MixingTimelist*mean(S.T.AXR_T1app3)) *exp(-MixingTimelist(1)*mean(S.T.AXR_T1app3));
theory=theory/normfac
hl = line(MixingTimelist,theory);%/Imean(1)
 hl.LineStyle = '-';
 hl.Color = [0 0 0];
 
load('SpinalCord_Fixed_20181214_tmMax1000.mat')
normfac=mean(S.T.I_1(:,1));
 MixingTimelist=S.MixingTimelist';

  %% I_4

Imean=mean(S.T.I_4,1)';
Istd=std(S.T.I_4,0,1)';
Imean=Imean/normfac;
Istd=Istd/normfac;
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(4,:);
%  hf.FaceAlpha = .6;

hl4 = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl4.Marker = 'o';
hl4.MarkerFaceColor=COLORS(4,:);
   hl4.LineStyle = 'none';
 hl4.MarkerSize = 3;
 hl4.Color = [0.7 0.7 0.7];
  hl4.DisplayName='$I_{pt4}$'

 
 theory=mean(S.T.I0_T1app4)*exp(-MixingTimelist*mean(S.T.AXR_T1app4));
theory=theory/normfac
hl = line(MixingTimelist,theory);%/Imean(1)
 hl.LineStyle = '-';
 hl.Color = [0 0 0];

 
  legend([hl1 hl2 hl3 hl4],'Box','on')

%% Plot attenuation and fits
h                   = axes();
h.Units             = 'centimeters';
h.FontName          = FontName;
h.FontSize          = FontSize;
h.FontWeight        = FontWeight;
h.Position          = [1.25 1.25 6 2.5];
h.YTick             = [.1 .2];
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
h.XLabel.String     = '$ t_m$ [ms]';
h.YLabel.String     = '$I/I_0$';
h.YScale            = 'log';
h.XLim(2)           = 100;
h.YLim           = [.09 .22];
h.YRuler.MinorTickValues=(9:22)/100

h.YLabel.Units      = 'centimeters';
h.YLabel.Position(1) = -0.8;

h.YMinorTick = 'on';
h.XMinorTick = 'on';
h.TickLength = [.02 .02] ;
h.TickDir    = 'out';
h.Box               = 'off';

hold on

% load('SpinalCord_Fixed_20181214_multibd.mat')
% MixingTimelist=S.MixingTimelist';
% cc=jet(30);
% for i=1:30;%length(S.T.I_hold(1,1,:))/2
%     Imean=mean(S.T.I_hold(:,:,i+1),1)/mean(S.T.I_hold(:,1,1),1);
%     hl = line(MixingTimelist,Imean);%/Imean(1)
%     hl.LineStyle = 'none';
%         hl.Color = cc(31-i,:);
%         hl.Marker = '.';
%     Imean=mean(S.T.I_hold(:,:,end-i+1),1)/mean(S.T.I_hold(:,1,1),1);
%     hl = line(MixingTimelist,Imean);%/Imean(1)
%     hl.LineStyle = 'none';
%     hl.Color = cc(31-i,:);
%     hl.Marker = '.';
%     hl.MarkerSize = 10;
%   %  w=waitforbuttonpress;
% end
%% I_1
load('SpinalCord_Fixed_20181214_tmMax1000.mat')
MixingTimelist=S.MixingTimelist';
Imean=mean(S.T.I_1,1)';
Istd=std(S.T.I_1,0,1)';
Imean=Imean/normfac;
Istd=Istd/normfac;

Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end
bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(1,:);
%  hf.FaceAlpha = .5;

hl = line(MixingTimelist,Imean);%/Imean(1)
% hl.LineStyle = 'none';
 hl.Marker = 'o';
  hl.LineStyle = 'none';
  hl.MarkerFaceColor=COLORS(1,:);
 hl.MarkerSize = 3;
 hl.Color = [0.8 0.8 0.8];

theory=mean(S.T.I0_T1app1)*exp(-MixingTimelist*mean(S.T.AXR_T1app1));
theory=theory/normfac
hl = line(MixingTimelist,theory);%/Imean(1)
 hl.LineStyle = '-';
 hl.Color = [0 0 0];
 
 %% I_2

Imean=mean(S.T.I_2,1)';
Istd=std(S.T.I_2,0,1)';
Imean=Imean/normfac;
Istd=Istd/normfac;
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(5,:);
%  hf.FaceAlpha = .6;

hl = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl.Marker = 'o';
hl.MarkerFaceColor=COLORS(5,:);
   hl.LineStyle = 'none';
 hl.MarkerSize = 7;
 hl.Color = [0 0 0];
 
%  theory=mean(S.T.I0_T1app2)*exp(-MixingTimelist*mean(S.T.AXR_T1app2));
% theory=theory/normfac
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [.9 .9 .9];
 %% I_3

Imean=mean(S.T.I_3,1)';
Istd=std(S.T.I_3,0,1)';
Imean=Imean/normfac;
Istd=Istd/normfac;
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(3,:);
%  hf.FaceAlpha = .6;

hl = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl.Marker = 'o';
hl.MarkerFaceColor=COLORS(3,:);
   hl.LineStyle = 'none';
 hl.MarkerSize = 3;
 hl.Color = [0.3 0.3 0.3];
 
 load('SpinalCord_Fixed_20181214_tmMin100Max1000.mat')
 MixingTimelist=S.MixingTimelist';

 theory=mean(S.T.I0_T1app3)*exp(-MixingTimelist*mean(S.T.AXR_T1app3)) *exp(-MixingTimelist(1)*mean(S.T.AXR_T1app3));
theory=theory/normfac
hl = line(MixingTimelist,theory);%/Imean(1)
 hl.LineStyle = '-';
 hl.Color = [0 0 0];
 
load('SpinalCord_Fixed_20181214_tmMax1000.mat')
 MixingTimelist=S.MixingTimelist';

  %% I_4

Imean=mean(S.T.I_4,1)';
Istd=std(S.T.I_4,0,1)';
Imean=Imean/normfac;
Istd=Istd/normfac;
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(4,:);
%  hf.FaceAlpha = .6;

hl = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl.Marker = 'o';
hl.MarkerFaceColor=COLORS(4,:);
   hl.LineStyle = 'none';
 hl.MarkerSize = 3;
 hl.Color = [0.7 0.7 0.7];
 
 theory=mean(S.T.I0_T1app4)*exp(-MixingTimelist*mean(S.T.AXR_T1app4));
theory=theory/normfac
hl = line(MixingTimelist,theory);%/Imean(1)
 hl.LineStyle = '-';
 hl.Color = [0 0 0]; 
 hl.LineWidth=.5;
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.LineWidth=.25;
%  hl.Color = [0 0 0]; 
%fig.Renderer='painters';

%% Save figure.
print(fig,'williamson_fig4_zoom.eps','-depsc')
%print(fig,'williamson_fig4.png','-dpng')
print(fig,'williamson_fig4_zoom.tif','-dtiff','-r2048')


