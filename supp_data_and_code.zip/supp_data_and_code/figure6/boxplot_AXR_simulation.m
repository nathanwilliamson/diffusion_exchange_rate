%testing_AXR


%% Initialization.
%close all
clear all
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% load data.
load('SimulationFits_restricted_SNR200.mat');

AXRarray=NaN(100,5);

% D_0_25=2.15E-9; %m^2/s
% D_0_7=1.34E-9; %m^2/s
% D_0=[D_0_25,D_0_7,D_0_25];



AXRarray(:,5-4)=S(1,1).T.AXR;
AXRarray(:,5-3)=S(1,1).T.AXR_I3_N24;
AXRarray(:,5-2)=S(1,1).T.AXR_I3;
AXRarray(:,5-1)=S(1,1).T.AXR_I3_BLsubtract;
AXRarray(:,5)=S(1,1).T.AXR_I3_rapid;

%x=[1:5, 7:11];
x=[1:5];

% figure
% h=boxplot2(AXRarray,x);


%% Initialize figure.

COLORS = 1/255 * [  55  80  162 ; ...
    93  187 70  ; ...
    241 156 31  ; ...
    237 28  36  ; ...
    129 41  134 ];
COLORSpatch = 1/255 * [255 255 100  ; ...
    100 255 100  ; ...
    150 255 255  ; ...
    255 200 100  ; ...
    230 150 255];

col=get(groot,'DefaultAxesColorOrder');
fig                 = figure();
fig.Units           = 'centimeters';
fig.PaperUnits      = 'centimeters';
fig.Position        = [0 0 8 5];
fig.PaperPosition   = fig.Position;

FontName            = 'helvetica';
FontSize            = 7;
FontWeight          = 'normal';



%% BoxPlot


h                   = axes();
h.Units             = 'centimeters';
h.FontName          = FontName;
h.FontSize          = FontSize;
h.FontWeight        = FontWeight;
h.Position          = [1.25 1.25 6 3.25];
%h.YTick             = [.001 .01 .1 1];
h.XTick             = [1:5];
h.XTickLabel             = {'1' '2' '3' '4' '5'};
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
h.XLabel.String     = 'Method ';
h.YLabel.String     = '$\mathrm{AXR\ [s^{-1}]}$';
%h.YScale            = 'log';
 h.XLim(2)           = 6;
% h.YLim(1)           = 1e-3;
 h.YLim(2)           = 160;

h.YLabel.Units      = 'centimeters';
h.YLabel.Position(1) = -0.8;
h.YGrid = 'on';
% 
% h.YMinorTick = 'on';
% h.XMinorTick = 'on';
% h.TickLength = [.02 .02] ;
% h.TickDir    = 'out';
% h.Box               = 'off';

hold on

hl = line([0,6],[100,100]);
% x=get(h(j*5-1),'XData');
% y=AXRnoNoise(2)*length(x);
% hl = line(x,y);
 hl.LineStyle = '-';

% hl.MarkerFaceColor=COLORS(3,:);

  hl.Color = [0 0 0];

h=violin(AXRarray*1000,'x',x,'facecolor',COLORSpatch);
h=boxplot2(AXRarray*1000,x,'barwidth',0.5,'notch','on');

 h = findobj(gca,'Tag','Box');
 for j=1:length(h)/5
    
    hf=patch(get(h(j*5),'XData'),get(h(j*5),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(1,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-1),'XData'),get(h(j*5-1),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(2,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-2),'XData'),get(h(j*5-2),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(3,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-3),'XData'),get(h(j*5-3),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(4,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-4),'XData'),get(h(j*5-4),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(5,:);
    %hf.FaceAlpha = .6;
 end
h=boxplot2(AXRarray*1000,x,'barwidth',0.5,'notch','on');

 %% define value which is converged to in the absence of noise
%%%2 comp. D model
 %AXRnoNoise=[0.0999,0.0962,0.1041,0.1051,0.1081]*1000;
%%%restricted model
AXRnoNoise=[0.0999,0.0974,0.1029,0.1036,0.1057]*1000;

hl = line([1,2 3 4 5],AXRnoNoise);
% x=get(h(j*5-1),'XData');
% y=AXRnoNoise(2)*length(x);
% hl = line(x,y);
% hl.LineStyle = 'none';
  hl.Marker = 'o';
% hl.MarkerFaceColor=COLORS(3,:);
    hl.LineStyle = 'none';
  hl.MarkerSize = 3;
  hl.Color = [0 0 0];
%%
% figure
% h=boxplot2(slopeb13array,x);

 %% Save figure.
 fig.Renderer='Painters';
 %% Save figure.
%print(fig,'williamson_fig_AXR_simulation.eps','-depsc')
print(fig,'williamson_suppfig_AXR_simulation_restricted.eps','-depsc')
% print(fig,'williamson_fig_AXR_simulation.png','-dpng','-r2048')
% %print(fig,'williamson_figure_1Ddiff_normal_bw.eps','-deps')
% print(fig,'williamson_fig_AXR_simulation.tif','-dtiff','-r2048')

