clear all
close all
%% Random stream.

random_seed = round( sum( 1e6 * clock() ) );
s = RandStream('mt19937ar', 'Seed', random_seed);
RandStream.setGlobalStream(s);
%%
%% define parameters
D0=2.15E-9; %m^2/s
De=1E-9;
Di=1E-11;
AXR=0.1;

%% compute exchange fractions
%MixingTimelist=[0]; %testing

MixingTimelist=[ 0.2,1,2,4,7,10,20,40,80,160,300]; %spinal cord

% taulist1=[0,0,0.5794,0.73]*1E-3;  % testing with bd=+-bs
% taulist2=[0,0.73,0.5794,0]*1E-3;

taulist1=[0.2,0.2,0.593,0.735]*1E-3;  % new tauMin=0.2 ms, bmin= 0.089 s/mm2  #point near bs=0, then 3 pts at bs=4.5E9
taulist2=[0.213,0.735,0.58,0.2]*1E-3;
b1=taulist1.^3*11.1235;
b2=taulist2.^3*11.1235;
bd=(b2-b1);
bs=(b1+b2);
Ds=(De+Di)/2;
Dd=(De-Di)/2;
C=exp(bs(2)*Ds)/Dd^2; % eq 9 in Cai 2018

ntau=length(taulist1);
nmix=length(MixingTimelist);


figure
hold on
% plot (bd(2:4),I(2:4),'o')
%%

S=struct();
si=1;
S(si).scanMat=[1 1];
SNR=200;



    S(si).MixingTimelist=MixingTimelist;

    for cii=1:length(S(si).scanMat(:,1))
        k=0;
        for ciii=S(si).scanMat(cii,1):S(si).scanMat(cii,2)
                set=ciii;
                k=k+1;
            for i=1:nmix
                for j=1:ntau

                        I(j)=model1R(taulist1(j),taulist2(j),MixingTimelist(i),De,Di,AXR);
                        %I(j)=model3R(taulist1(j),taulist2(j),MixingTimelist(i),De,AXR);
                        %I(j)=I(j)+randn(1,1)/SNR;
                        S(si).T(cii).I_hold(k,i,j)=I(j);

                end       
                S(si).T(cii).exchFrac1(k,i)=(I(2)-2*I(3)+I(4))/(bd(2)^2*I(1))*C;
                S(si).T(cii).exchFrac_normb1b2(k,i)=(I(2)-2*I(3)+I(4))/(bd(2)^2*mean([I(2),I(4)]))*C;
                S(si).T(cii).exchFrac_normb1(k,i)=(I(2)-I(3))/(bd(2)^2*I(2))*C;  %/2.5*.45;

                S(si).T(cii).D_1(k,i)=(log(I(2))-log(I(1)))/(-b2(2));
                S(si).T(cii).I_1(k,i)=I(1);                
                S(si).T(cii).I_2(k,i)=I(2);
                S(si).T(cii).I_3(k,i)=I(3);               
                S(si).T(cii).I_4(k,i)=I(4);
plot (bd(2:4),I(2:4),'o')
            end
         end
    end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% tau=linspace(0,0.01);
% figure
% hold on
% plot(tau,rest(tau),'--');
% plot(tau,restFull(tau),'-.');
% plot(tau,restGreb(tau),'.');

%save('SimulationData_SNR50.mat','S')
save('SimulationData_GammaRelax.mat','S')

%% define functions
function I=model1(tau1,tau2,tm,De,Di,AXR);
fi=0.5;
fe=1-fi;
f0=0;

f=exch(tm,f0,fe,fi,AXR);
I=(fe-f/2)*free(tau1,De)*free(tau2,De)+f/2*free(tau1,De)*free(tau2,Di)+f/2*free(tau1,Di)*free(tau2,De)+(fi-f/2)*free(tau1,Di)*free(tau2,Di);
end

function I=model1R(tau1,tau2,tm,De,Di,AXR);
fi=0.25;
fe=1-fi;
f0=0;
R1_1=1/(1E3); % [1/ms]
R1mean=1/(1E2); % [1/ms]
R1std=1/(1E3);
% R1_2=1/(2E3);
% f_2sx=0.9;
% f_free=1-f_2sx;

f=exch(tm,f0,fe,fi,AXR);

I_2sx=(fe-f/2)*free(tau1,De)*free(tau2,De)+f/2*free(tau1,De)*free(tau2,Di)+f/2*free(tau1,Di)*free(tau2,De)+(fi-f/2)*free(tau1,Di)*free(tau2,Di);
%I_2sx=I_2sx*relax(tm,R1_1);
I_2sx=I_2sx*relaxgamma(tm,R1mean,R1std);

% I_free=free(tau1,D0)*free(tau2,D0)*relax(tm,R1_2);
% I=f_free*I_free+f_2sx*I_2sx;
I=I_2sx;
end




function I=model3R(tau1,tau2,tm,De,AXR);
R1_1=1/(1E3);
R1_2=1/(2E3);
fi=0.25;
fe=1-fi;
f0=0;
%f_2sx=0.9;
%f_free=1-f_2sx;

f=exch(tm,f0,fe,fi,AXR);
I_2sx=(fe-f/2)*free(tau1,De)*free(tau2,De)+f/2*free(tau1,De)*restFull(tau2)+f/2*restFull(tau1)*free(tau2,De)+(fi-f/2)*restFull(tau1)*restFull(tau2);
I_2sx=I_2sx*relax(tm,R1_1);
%I_free=free(tau1,D0)*free(tau2,D0)*relax(tm,R1_2);
%I=f_free*I_free+f_2sx*I_2sx;
I=I_2sx;
end


% function I=model4(tau1,tau2,tm,D0,AXR);
% fi=0.2;
% fe=1-fi;
% f0=0;
% 
% f=exch(tm,f0,fe,fi,AXR);
% I=(fe-f/2)*free(tau1,D0)*free(tau2,D0)+f/2*free(tau1,D0)*restGreb(tau2)+f/2*restGreb(tau1)*free(tau2,D0)+(fi-f/2)*restGreb(tau1)*restGreb(tau2);
% end


function y=rest(tau)
gamma=267.52218744E6;%42.577478518E6; %Hz/T
g=15.2689; %T/m
D0=2.15E-9; %m^2/s
R=800E-9; %nm
y =  exp(-8/175 * (R^4 * gamma^2 * g^2/D0) * (2 * tau -  (581/840) *(R^2/D0)) );
end 

function y=restFull(tau)
gamma=267.52218744E6;%42.577478518E6; %Hz/T
g=15.2689; %T/m
D0=2.15E-9; %m^2/s
R=800E-9; %nm
alpha_m=[2.0815, 5.940, 9.206, 12.405, 15.579]'/R;
y=exp(-2.*gamma.^2.*g.^2./D0.*sum(alpha_m.^(-4)./(alpha_m.^2.*R^2-2).*(2.*tau-(3-4.*exp(-alpha_m.^2.*D0.*tau)+exp(-alpha_m.^2.*D0.*2.*tau))./(alpha_m.^2.*D0)),1));
end

function y=restGreb(tau)
gamma=267.52218744E6;%42.577478518E6; %Hz/T
g=15.2689; %T/m
D0=2.15E-9; %m^2/s
R=800E-9; %nm
p=D0*tau/R^2;
q=gamma*g*tau*R;
xi1=8/175;
xi2=83/7875;
y =  exp(-q.^2.*(2*xi1*p.^(-1)-3*xi2.*p.^(-2))); %from plugging eq. 125 into eq. 90
end 
 
function y = free(tau,D)
gamma=267.52218744E6;%42.577478518E6; %Hz/T
g=15.2689; %T/m

    y = exp(-2/3*D*gamma^2* g^2 *tau^3);
    
end

function f=exch(tm,f0,fe,fi,k)
fss=2*fi*fe ;
f = (fss-f0)*(1 - exp(-tm*k))+f0;
end

function y=relax(tm,R1)
y=exp(-tm*R1);
end
function y=relaxgamma(tm,R1mean,R1std)
y=(1+tm*R1std^2/R1mean)^(-R1mean^2/R1std^2);
end