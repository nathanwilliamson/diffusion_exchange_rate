%% Initialization.

clear all
%clc
close all hidden

%% Random stream.

random_seed = round( sum( 1e6 * clock() ) );
s = RandStream('mt19937ar', 'Seed', random_seed);
RandStream.setGlobalStream(s);
load('SimulationData_GammaRelax.mat')
%%
MixingTimelist=[0.2,1,2,4,7,10,20,40,80,160,300]; %spinal cord

%% fit exchange rate
addpath('diffusion_semiparametric');
number_of_fits = 100;
number_of_mc_fits = 0;
model = {{'exponential'}};

baselineAXR = true;
clear I_AXR
lastpt= length(MixingTimelist);
firstpt=1;
NptEnd=0; %number of points to drop from end
MixingTimepts=[1 2 3 4 5 6 7 8 9 10 11];

 MTlistFit=MixingTimelist(MixingTimepts);%MixingTimelist(firstpt:lastpt);
 
 MixingTimepts_2=[1 2 3 4 5 6];
MixingTimeptsBaseline=[10 11];
 MTlistFit_2=MixingTimelist(MixingTimepts_2);   
 baselineT1=false;
 

 
 MTlistFit_2ptT1=MixingTimelist([1 11]);
 
 MTlistFit_rapid=MixingTimelist([1 6]);
 for si=1:length(S)

    S(si).MixingTimelist2=MTlistFit_2;
    S(si).MixingTimelist_2ptT1=MTlistFit_2ptT1;
    S(si).MixingTimelist_rapid= MTlistFit_rapid;
 end


 
for si=1:length(S)
    
    for cii=1:length(S(si).scanMat(:,1))
        k=0;
         for ciii=S(si).scanMat(cii,1):S(si).scanMat(cii,2)
            set=ciii;
            k=k+1;
            %% fit exchange rate with I(1) normalization point
            S(si).T(cii).I_AXR(k,:)=S(si).T(cii).exchFrac1(k,MixingTimepts(end))-S(si).T(cii).exchFrac1(k,MixingTimepts);
            %I_AXR=I_AXR/I_AXR(1)
            %%% Fit model and estimate parameters.

            S(si).T(cii).fit{k,1} = analyze(MTlistFit, S(si).T(cii).I_AXR(k,:), model, baselineAXR, number_of_fits, number_of_mc_fits);

            %print_results(fit{k,1});
            %plot_fit_and_residuals(MTlistFit, S(si).T(cii).I_AXR(k,:), S(si).T(cii).fit{k,1});


            S(si).T(cii).baseline(k)=S(si).T(cii).fit{k,1}.baseline;
            S(si).T(cii).I0(k)=S(si).T(cii).fit{k,1}.I0;
%             if length(model)==2
%                 if fit{k,1}.components{1,1}.D<fit{k,1}.components{2,1}.D
%                 S(si).T(cii).AXR(k,1)=fit{k,1}.components{1,1}.D;
%                 S(si).T(cii).AXR(k,2)=fit{k,1}.components{2,1}.D;
%                 S(si).T(cii).theta(k)=fit{k,1}.components{1,1}.theta;
%                 else
%                 S(si).T(cii).AXR(k,1)=fit{k,1}.components{2,1}.D;
%                 S(si).T(cii).AXR(k,2)=fit{k,1}.components{1,1}.D;
%                 S(si).T(cii).theta(k)=fit{k,1}.components{2,1}.theta
%                 end
%             else
                S(si).T(cii).AXR(k,1)=S(si).T(cii).fit{k,1}.components{1,1}.D;
%            end
            %% fit exchange rate fron only I(3)
            %%% Fit model and estimate parameters.

            S(si).T(cii).fit_I3only{k,1} = analyze(MTlistFit, S(si).T(cii).I_3(k,:), model, baselineAXR, number_of_fits, number_of_mc_fits);

            %plot_fit_and_residuals(MTlistFit, S(si).T(cii).I3_N24(k,:), S(si).T(cii).fit_I3_N24{k,1});

            S(si).T(cii).I0_I3only(k)=S(si).T(cii).fit_I3only{k,1}.I0;
            S(si).T(cii).baseline_I3only(k)=S(si).T(cii).fit_I3only{k,1}.baseline;
            S(si).T(cii).AXR_I3only(k,1)=S(si).T(cii).fit_I3only{k,1}.components{1,1}.D;

            %% fit exchange rate with I(2) normalization

            S(si).T(cii).I3_N24(k,:)=S(si).T(cii).I_3(k,:)./S(si).T(cii).I_2(k,:);
            %I_AXR_I123(k,:)=I_AXR_I123(k,:)/I_AXR_I123(k,1)
            %%% Fit model and estimate parameters.

            S(si).T(cii).fit_I3_N24{k,1} = analyze(MTlistFit, S(si).T(cii).I3_N24(k,:), model, baselineAXR, number_of_fits, number_of_mc_fits);

            %plot_fit_and_residuals(MTlistFit, S(si).T(cii).I3_N24(k,:), S(si).T(cii).fit_I3_N24{k,1});

            S(si).T(cii).I0_I3_N24(k)=S(si).T(cii).fit_I3_N24{k,1}.I0;
            S(si).T(cii).baseline_I3_N24(k)=S(si).T(cii).fit_I3_N24{k,1}.baseline;
            S(si).T(cii).AXR_I3_N24(k,1)=S(si).T(cii).fit_I3_N24{k,1}.components{1,1}.D;

         %% fit apparent T1 from I(2), 

            %%% Fit model and estimate parameters.

            S(si).T(cii).fit_I2{k,1} = analyze(MTlistFit, S(si).T(cii).I_2(k,:), model, baselineT1, number_of_fits, number_of_mc_fits);

            %plot_fit_and_residuals(MTlistFit, S(si).T(cii).I_2(k,:), S(si).T(cii).fit_I2{k,1});

            S(si).T(cii).I0_T1app2(k)=S(si).T(cii).fit_I2{k,1}.I0;
            S(si).T(cii).R1_T1app2(k,1)=S(si).T(cii).fit_I2{k,1}.components{1,1}.D;
         %% fit apparent T1 from I(4), 

            %%% Fit model and estimate parameters.

            S(si).T(cii).fit_I4{k,1} = analyze(MTlistFit, S(si).T(cii).I_4(k,:), model, baselineT1, number_of_fits, number_of_mc_fits);



            S(si).T(cii).I0_T1app4(k)=S(si).T(cii).fit_I4{k,1}.I0;
            S(si).T(cii).R1_T1app4(k)=S(si).T(cii).fit_I4{k,1}.components{1,1}.D;


            %% fit exchange rate from I(3), accounting for T1 in the tissue

            I_AXR_I3_temp(k,:)= S(si).T(cii).I_3(k,MixingTimepts)./exp(-MTlistFit*S(si).T(cii).R1_T1app2(k,1));

            S(si).T(cii).I_AXR_I3(k,:)=I_AXR_I3_temp(k,MixingTimepts)-mean(I_AXR_I3_temp(k,MixingTimeptsBaseline),2);
            %%% Fit model and estimate parameters.

            S(si).T(cii).fit_I3{k,1} = analyze(MTlistFit, S(si).T(cii).I_AXR_I3(k,:), model, baselineAXR, number_of_fits, number_of_mc_fits);

            %plot_fit_and_residuals(MTlistFit, S(si).T(cii).I_AXR_I3(k,:), S(si).T(cii).fit_I3{k,1} );

            %%% 1st order exchange rate equation is defined by

            S(si).T(cii).I0_I3(k)=S(si).T(cii).fit_I3{k,1}.I0;
            S(si).T(cii).AXR_I3(k,1)=S(si).T(cii).fit_I3{k,1}.components{1,1}.D;
            S(si).T(cii).baseline_I3(k,1)=S(si).T(cii).fit_I3{k,1}.baseline;

            %% fit exchange rate from I(3), accounting for T1 in the tissue, subtracting BL and fitting only the initial decay
            baseline=false;

            %%% Fit model and estimate parameters.

            S(si).T(cii).fit_I3_BLsubtract{k,1} = analyze(MTlistFit_2, S(si).T(cii).I_AXR_I3(k,MixingTimepts_2), model, baseline, number_of_fits, number_of_mc_fits);

            %plot_fit_and_residuals(MTlistFit_2, S(si).T(cii).I_AXR_I3(k,MixingTimepts_2),  S(si).T(cii).fit_I3_BLsubtract{k,1});

            %%% 1st order exchange rate equation is defined by

            S(si).T(cii).I0_I3_BLsubtract(k)=S(si).T(cii).fit_I3_BLsubtract{k,1}.I0;
            S(si).T(cii).AXR_I3_BLsubtract(k,1)=S(si).T(cii).fit_I3_BLsubtract{k,1}.components{1,1}.D;
            S(si).T(cii).baseline_I3_BLsubtract(k,1)=0;

            %% fit apparent T1 from I(2), only 2 pts 
            number_of_fits = 1000;
            %%% Fit model and estimate parameters.
            S(si).T(cii).I_2_2pt(k,:)=S(si).T(cii).I_2(k,[1 11]);
            S(si).T(cii).fit_I2_2pt{k,1} = analyze(MTlistFit_2ptT1, S(si).T(cii).I_2_2pt(k,:), model, baselineT1, number_of_fits, number_of_mc_fits);

            %plot_fit_and_residuals(MTlistFit_2ptT1, S(si).T(cii).I_2_2pt(k,:), S(si).T(cii).fit_I2_2pt{k,1});

            S(si).T(cii).I0_T1app2_2pt(k)=S(si).T(cii).fit_I2_2pt{k,1}.I0;
            S(si).T(cii).R1_T1app2_2pt(k,1)=S(si).T(cii).fit_I2_2pt{k,1}.components{1,1}.D;
            %% fit exchange rate from I(3), accounting for T1 in the tissue, subtracting BL and fitting only two pts (Most Rapid)
            baseline=false;
            
            I_AXR_I3_rapid_temp(k,:)= S(si).T(cii).I_3(k,MixingTimepts)./exp(-MTlistFit*S(si).T(cii).R1_T1app2_2pt(k,1));

            S(si).T(cii).I_AXR_I3_rapid(k,:)=I_AXR_I3_rapid_temp(k,[1 6])-I_AXR_I3_rapid_temp(k,11);
            %%% Fit model and estimate parameters.

            S(si).T(cii).fit_I3_rapid{k,1} = analyze(MTlistFit_rapid, S(si).T(cii).I_AXR_I3_rapid(k,:), model, baseline, number_of_fits, number_of_mc_fits);

            %plot_fit_and_residuals(MTlistFit_rapid, S(si).T(cii).I_AXR_I3_rapid(k,:), S(si).T(cii).fit_I3_rapid{k,1} );

            %%% 1st order exchange rate equation is defined by

            S(si).T(cii).I0_I3_rapid(k)=S(si).T(cii).fit_I3_rapid{k,1}.I0;
            S(si).T(cii).AXR_I3_rapid(k,1)=S(si).T(cii).fit_I3_rapid{k,1}.components{1,1}.D;
            S(si).T(cii).baseline_I3_rapid(k,1)=0;      
              number_of_fits = 100 ;           
        end

    end
end

% 'AXR'
% S.T.AXR
% 'AXR_I3only'
% S.T.AXR_I3only
% 'AXR_I3_N24'
% S.T.AXR_I3_N24

save('SimulationFits_GammaRelax.mat','S');
%save(horzcat(S(si).sample,'.mat'),'S')
%save(horzcat('C:\Users\williamsonnh\Documents\MATLAB\DEXSY_MOUSE_paper2\repeatMeasurements\Data_exchange_',S(si).sample,'.mat','S'))
