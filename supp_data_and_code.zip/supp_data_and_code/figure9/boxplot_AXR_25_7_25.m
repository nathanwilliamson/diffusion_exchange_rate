%testing_AXR


%% Initialization.
close all
clear all
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% load data.
load('exchangeData_25_7_25_35_25_compareMethods.mat');

AXRarray=NaN(30,15);

D_0_25=2.15E-9; %m^2/s
D_0_7=1.34E-9; %m^2/s
D_0=[D_0_25,D_0_7,D_0_25];

for i=1:3

AXRarray(:,i*5-4)=Tfixed(i).AXR;
AXRarray(:,i*5-3)=Tfixed(i).AXR_I3_N24;
AXRarray(:,i*5-2)=Tfixed(i).AXR_I3;
AXRarray(:,i*5-1)=Tfixed(i).AXR_I3_BLsubtract;
AXRarray(:,i*5)=Tfixed(i).AXR_I3_rapid;
end
%x=[1:5, 7:11];
x=[1:5, 7:11, 13:17];

% figure
% h=boxplot2(AXRarray,x);




%% Initialize figure.

COLORS = 1/255 * [  55  80  162 ; ...
    93  187 70  ; ...
    241 156 31  ; ...
    237 28  36  ; ...
    129 41  134 ];
COLORSpatch = 1/255 * [255 255 100  ; ...
    100 255 100  ; ...
    150 255 255  ; ...
    255 200 100  ; ...
    230 150 255];

col=get(groot,'DefaultAxesColorOrder');
fig                 = figure();
fig.Units           = 'centimeters';
fig.PaperUnits      = 'centimeters';
fig.Position        = [0 0 8 5];
fig.PaperPosition   = fig.Position;

FontName            = 'helvetica';
FontSize            = 7;
FontWeight          = 'normal';


%% Plot attenuation and fits, localization scale



h                   = axes();
h.Units             = 'centimeters';
h.FontName          = FontName;
h.FontSize          = FontSize;
h.FontWeight        = FontWeight;
h.Position          = [1.25 1.25 6.5 3.25];
%h.YTick             = [.001 .01 .1 1];
h.XTick             = [3  9  15];
h.XTickLabel             = [25 7 25];
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
h.XLabel.String     = '$ T$ [$^\circ$ C] ';
h.YLabel.String     = '$\mathrm{AXR}$ [$\mathrm{s^{-1}}$]';
%h.YScale            = 'log';
 h.XLim(2)           = 18;
% h.YLim(1)           = 1e-3;
 h.YLim(2)           = 160;

h.YLabel.Units      = 'centimeters';
h.YLabel.Position(1) = -0.8;
h.YGrid = 'on';
% 
% h.YMinorTick = 'on';
% h.XMinorTick = 'on';
% h.TickLength = [.02 .02] ;
% h.TickDir    = 'out';
% h.Box               = 'off';

hold on

h=violin(AXRarray*1000,'x',x,'facecolor',[COLORSpatch;COLORSpatch;COLORSpatch]);
h=boxplot2(AXRarray*1000,x,'barwidth',0.5,'notch','on');


 h = findobj(gca,'Tag','Box');
 for j=1:length(h)/5
    
    hf=patch(get(h(j*5),'XData'),get(h(j*5),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(1,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-1),'XData'),get(h(j*5-1),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(2,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-2),'XData'),get(h(j*5-2),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(3,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-3),'XData'),get(h(j*5-3),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(4,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-4),'XData'),get(h(j*5-4),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(5,:);
    %hf.FaceAlpha = .6;
 end
h=boxplot2(AXRarray*1000,x,'barwidth',0.5,'notch','on');
%%
% figure
% h=boxplot2(slopeb13array,x);

 %% Save figure.
 fig.Renderer='Painters';
 
 %% Save figure.

print(fig,'williamson_fig_AXR_25_7_25.eps','-depsc')
%print(fig,'williamson_figure_1Ddiff_normal_bw.eps','-deps')
print(fig,'williamson_fig_AXR_25_7_25.tif','-dtiff','-r300')

