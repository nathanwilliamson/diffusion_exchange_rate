close all
clear all


%% prepare data all at once
load('Data_25_7_25_35_25_CompareMethods.mat');
MixingTimelist=S(1).MixingTimelist2;

%% grab all f values in structs, Tfixed and Tlive, with 
ntm=length(MixingTimelist);
listf=[8:13];  
listl=[1:5];    
nlive=length(listl);
nfixed=length(listf);
Tfixed=struct();
nT=5;%
for cii=1:nT
    
%     Tfixed(cii).f=NaN(nfixed,ntm);
%     Tfixed(cii).exchFracInf=NaN(nfixed,1);
%     Tfixed(cii).exchFrac0=NaN(nfixed,1);
    Tfixed(cii).AXR=NaN(nfixed*5,1);
    Tfixed(cii).AXR_I3_N24=NaN(nfixed*5,1);  
%     Tfixed(cii).AXR_I3_N24_spread=NaN(nfixed,1);  
    Tfixed(cii).AXR_I3=NaN(nfixed*5,1);  
%     Tfixed(cii).AXR_I3_spread=NaN(nfixed,1);  
    Tfixed(cii).AXR_I3_BLsubtract=NaN(nfixed*5,1);  
%     Tfixed(cii).AXR_I3_BLsubtract_spread=NaN(nfixed,1);      
    Tfixed(cii).AXR_I3_rapid=NaN(nfixed*5,1);  
%     Tfixed(cii).AXR_I3_rapid_spread=NaN(nfixed,1);         
end
for cii=1:nT
%     Tlive(cii).f=NaN(nlive,ntm);
%     Tlive(cii).exchFracInf=NaN(nlive,1);
%     Tlive(cii).exchFrac0=NaN(nlive,1);    
    Tlive(cii).AXR=NaN(nlive*5,1);  
%     Tlive(cii).AXR_spread=NaN(nlive,1);  
    Tlive(cii).AXR_I3_N24=NaN(nlive*5,1);  
%     Tlive(cii).AXR_I3_N24_spread=NaN(nlive,1);  
    Tlive(cii).AXR_I3=NaN(nlive*5,1);  
%     Tlive(cii).AXR_I3_spread=NaN(nlive,1);  
    Tlive(cii).AXR_I3_BLsubtract=NaN(nlive*5,1);  
%     Tlive(cii).AXR_I3_BLsubtract_spread=NaN(nlive,1);      
    Tlive(cii).AXR_I3_rapid=NaN(nlive*5,1);  
%     Tlive(cii).AXR_I3_rapid_spread=NaN(nlive,1);     
end



for cii=1:nT
 count=1  ; 
    for ci=1:nfixed
        if length(S(listf(ci)).T)<cii
            continue
        end
        
%         Tfixed(cii).f(ci,1:length(S(listf(ci)).MixingTimelist)) = mean(S(listf(ci)).T(cii).exchFrac1,1);
%         Tfixed(cii).exchFracInf(ci) = mean(S(listf(ci)).T(cii).exchFracInf);
%         Tfixed(cii).exchFrac0(ci) = mean(S(listf(ci)).T(cii).I0);
%         Tfixed(cii).AXR(ci) = mean(S(listf(ci)).T(cii).AXR);

%         Tfixed(cii).f(ci,1:length(S(listf(ci)).MixingTimelist)) = mean(S(listf(ci)).T(cii).I_1D1,1);   
%         Tfixed(cii).exchFracInf(ci) = 0;
%         Tfixed(cii).exchFrac0(ci) = mean(S(listf(ci)).T(cii).I0_T1app1);
%         Tfixed(cii).AXR(ci) = mean(S(listf(ci)).T(cii).AXR_T1app1);
        
%         Tfixed(cii).f(ci,1:length(S(listf(ci)).MixingTimelist2)) = mean(S(listf(ci)).T(cii).I_AXR_I123_2,1);   
%         Tfixed(cii).exchFracInf(ci) = 0;
%         Tfixed(cii).exchFrac0(ci) = mean(S(listf(ci)).T(cii).I0_I123_2);
l=length(S(listf(ci)).T(cii).AXR);
        Tfixed(cii).AXR(count:count+l-1) = S(listf(ci)).T(cii).AXR;
%         Tfixed(cii).AXR_spread(ci) = std(S(listf(ci)).T(cii).AXR)/mean(S(listf(ci)).T(cii).AXR);
        Tfixed(cii).AXR_I3_N24(count:count+l-1) = S(listf(ci)).T(cii).AXR_I3_N24;
%         Tfixed(cii).AXR_I3_N24_spread(ci) = std(S(listf(ci)).T(cii).AXR_I3_N24)/mean(S(listf(ci)).T(cii).AXR_I3_N24);
        Tfixed(cii).AXR_I3(count:count+l-1) = S(listf(ci)).T(cii).AXR_I3;
%         Tfixed(cii).AXR_I3_spread(ci) = std(S(listf(ci)).T(cii).AXR_I3)/mean(S(listf(ci)).T(cii).AXR_I3);
        Tfixed(cii).AXR_I3_BLsubtract(count:count+l-1) = S(listf(ci)).T(cii).AXR_I3_BLsubtract;
%         Tfixed(cii).AXR_I3_BLsubtract_spread(ci) = std(S(listf(ci)).T(cii).AXR_I3_BLsubtract)/mean(S(listf(ci)).T(cii).AXR_I3_BLsubtract);
        Tfixed(cii).AXR_I3_rapid(count:count+l-1) = S(listf(ci)).T(cii).AXR_I3_rapid;
%         Tfixed(cii).AXR_I3_rapid_spread(ci) = std(S(listf(ci)).T(cii).AXR_I3_rapid)/mean(S(listf(ci)).T(cii).AXR_I3_rapid);        
        count=count+l;
    end
 
    
    
end


% 
% for cii=1:nT
%     for ci=1:nlive
%         if length(S(listl(ci)).T)<cii
%             continue
%         end
%         
% %         Tlive(cii).f(ci,1:length(S(listl(ci)).MixingTimelist)) = mean(S(listl(ci)).T(cii).exchFrac1,1);
% %         
% %         Tlive(cii).exchFracInf(ci) = mean(S(listl(ci)).T(cii).exchFracInf);
% %         Tlive(cii).exchFrac0(ci) = mean(S(listl(ci)).T(cii).I0);
% %         Tlive(cii).AXR(ci) = mean(S(listl(ci)).T(cii).AXR);
% 
% %         Tlive(cii).f(ci,1:length(S(listl(ci)).MixingTimelist)) = mean(S(listl(ci)).T(cii).I_1D1,1);
% %         
% %         Tlive(cii).exchFracInf(ci) = 0;
% %         Tlive(cii).exchFrac0(ci) = mean(S(listl(ci)).T(cii).I0_T1app1);
% %         Tlive(cii).AXR(ci) = mean(S(listl(ci)).T(cii).AXR_T1app1);      
% 
%         Tlive(cii).AXR(ci) = mean(S(listl(ci)).T(cii).AXR);
%         Tlive(cii).AXR_spread(ci) = std(S(listl(ci)).T(cii).AXR)/mean(S(listl(ci)).T(cii).AXR);
%         Tlive(cii).AXR_I3_N24(ci) = mean(S(listl(ci)).T(cii).AXR_I3_N24);
%         Tlive(cii).AXR_I3_N24_spread(ci) = std(S(listl(ci)).T(cii).AXR_I3_N24)/mean(S(listl(ci)).T(cii).AXR_I3_N24);
%         Tlive(cii).AXR_I3(ci) = mean(S(listl(ci)).T(cii).AXR_I3);
%         Tlive(cii).AXR_I3_spread(ci) = std(S(listl(ci)).T(cii).AXR_I3)/mean(S(listl(ci)).T(cii).AXR_I3);
%         Tlive(cii).AXR_I3_BLsubtract(ci) = mean(S(listl(ci)).T(cii).AXR_I3_BLsubtract);
%         Tlive(cii).AXR_I3_BLsubtract_spread(ci) = std(S(listl(ci)).T(cii).AXR_I3_BLsubtract)/mean(S(listl(ci)).T(cii).AXR_I3_BLsubtract);
%         Tlive(cii).AXR_I3_rapid(ci) = mean(S(listl(ci)).T(cii).AXR_I3_rapid);
%         Tlive(cii).AXR_I3_rapid_spread(ci) = std(S(listl(ci)).T(cii).AXR_I3_rapid)/mean(S(listl(ci)).T(cii).AXR_I3_rapid);        
%  
%     end
%     
% end
% 
% % for ci=1:nT
% % 
% % %             arrhenius_EaFixed(ci) = S(listf(ci)).arrhenius_Ea; 
% % %         arrhenius_AFixed(ci) = S(listf(ci)).arrhenius_A; 
% %          
% % %         arrhenius_EaFixed(ci) = S(listf(ci)).arrhenius_Ea_T1app; 
% % %         arrhenius_AFixed(ci) = S(listf(ci)).arrhenius_A_T1app; 
% %         
% %         arrhenius_EaFixed(ci) = S(listf(ci)).arrhenius_Ea_bd0; 
% %         arrhenius_AFixed(ci) = S(listf(ci)).arrhenius_A_bd0; 
% %         
% % 
% % end
% 
% % for ci=1:nT
% % 
% % %         arrhenius_EaLive(ci) = S(listl(ci)).arrhenius_Ea; 
% % %         arrhenius_ALive(ci) = S(listl(ci)).arrhenius_A; 
% %        
% % %         arrhenius_EaLive(ci) = S(listl(ci)).arrhenius_Ea_T1app; 
% % %         arrhenius_ALive(ci) = S(listl(ci)).arrhenius_A_T1app; 
% %          
% %         arrhenius_EaLive(ci) = S(listl(ci)).arrhenius_Ea_bd0; 
% %         arrhenius_ALive(ci) = S(listl(ci)).arrhenius_A_bd0; 
% %         
% % end 
% 
% save('exchangeData_25_7_25_35_25_compareMethods_test.mat','Tfixed','Tlive','MixingTimelist')
% 
% 
 save('exchangeData_25_7_25_35_25_compareMethods.mat','Tfixed','MixingTimelist');
