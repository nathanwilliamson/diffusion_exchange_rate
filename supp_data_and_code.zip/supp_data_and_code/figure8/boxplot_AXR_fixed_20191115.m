%testing_AXR


%% Initialization.
close all
clear all
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% load data.
load('Data_20191115_compareMethods.mat');

AXRarray=NaN(100,5);

D_0_25=2.15E-9; %m^2/s
D_0_7=1.34E-9; %m^2/s
D_0=[D_0_25,D_0_7,D_0_25];



AXRarray(:,5-4)=S.T.AXR;
AXRarray(:,5-3)=S.T.AXR_I3_N24;
AXRarray(:,5-2)=S.T.AXR_I3;
AXRarray(:,5-1)=S.T.AXR_I3_BLsubtract;
AXRarray(:,5)=S.T.AXR_I3_rapid;

%x=[1:5, 7:11];
x=[1:5];

% figure
% h=boxplot2(AXRarray,x);




%% Initialize figure.

COLORS = 1/255 * [  55  80  162 ; ...
    93  187 70  ; ...
    241 156 31  ; ...
    237 28  36  ; ...
    129 41  134 ];
COLORSpatch = 1/255 * [255 255 100  ; ...
    100 255 100  ; ...
    150 255 255  ; ...
    255 200 100  ; ...
    230 150 255];

col=get(groot,'DefaultAxesColorOrder');
fig                 = figure();
fig.Units           = 'centimeters';
fig.PaperUnits      = 'centimeters';
fig.Position        = [0 0 8 12];
fig.PaperPosition   = fig.Position;

FontName            = 'helvetica';
FontSize            = 7;
FontWeight          = 'normal';


%% Plot attenuation and fits
h                   = axes();
h.Units             = 'centimeters';
h.FontName          = FontName;
h.FontSize          = FontSize;
h.FontWeight        = FontWeight;
h.Position          = [1.25 9 6 2.5];
%h.YTick             = [.01 .1 1];
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
h.XLabel.String     = '$ t_m$ [ms]';
h.YLabel.String     = '$I/I_0$';
%h.YScale            = 'log';

%h.XLim(2)           = 3.5;
h.YLim           = [0 3];

h.YLabel.Units      = 'centimeters';
h.YLabel.Position(1) = -0.8;

h.YMinorTick = 'on';
h.XMinorTick = 'on';
h.TickLength = [.02 .02] ;
h.TickDir    = 'out';
h.Box               = 'off';

hold on
symbol={'o','v','^','d','>','s','d'};
COLORS=get(groot,'DefaultAxesColorOrder');

%%% method 1
 bl=mean(S.T.I_AXR(:,11));
 norm=mean(S.T.I_AXR(:,1)-bl);
f=(S.T.I_AXR-bl)/norm;
MixingTimelist=S.MixingTimelist;

hl=errorbar(MixingTimelist,mean(f+.5*4,1),std(f,0,1));
hl.Marker=symbol{1}; hl.LineStyle='none';
hl.Color= [0 0 0];
hl.MarkerFaceColor=COLORSpatch(1,:);

MixingTimeArray=ones(1000,length(S.T.AXR)).*linspace(0,300,1000)';
Imodel=(S.T.I0.*exp(-MixingTimeArray.*S.T.AXR')+S.T.baseline-bl)/norm;
fmean=mean(Imodel,2);
fstd=std(Imodel,0,2);
plot(MixingTimeArray(:,1),mean(Imodel,2)+.5*4);

fpatch=[fmean+fstd;flipud(fmean-fstd)];
for i=1:length(fpatch)
    if fpatch(i)<1E-10
        fpatch(i)=1E-10;
    end
end
tpatch=[MixingTimeArray(:,1);flipud(MixingTimeArray(:,1))];

 hf = patch(tpatch,fpatch+.5*4,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORSpatch(1,:);
 hf.FaceAlpha = .6;

 %%% method 2 

 bl=mean(S.T.I3_N24(:,11));
 norm=mean(S.T.I3_N24(:,1)-bl);
f=(S.T.I3_N24-bl)/norm;
MixingTimelist=S.MixingTimelist;

hl=errorbar(MixingTimelist,mean(f,1)+.5*3,std(f,0,1));
hl.Marker=symbol{1}; hl.LineStyle='none';
hl.Color= [0 0 0];
hl.MarkerFaceColor=COLORSpatch(2,:);

MixingTimeArray=ones(1000,length(S.T.AXR)).*linspace(0,300,1000)';
Imodel=(S.T.I0_I3_N24.*exp(-MixingTimeArray.*S.T.AXR_I3_N24')+S.T.baseline_I3_N24-bl)/norm;
fmean=mean(Imodel,2);
fstd=std(Imodel,0,2);
plot(MixingTimeArray(:,1),mean(Imodel,2)+.5*3);

fpatch=[fmean+fstd;flipud(fmean-fstd)];
for i=1:length(fpatch)
    if fpatch(i)<1E-10
        fpatch(i)=1E-10;
    end
end
tpatch=[MixingTimeArray(:,1);flipud(MixingTimeArray(:,1))];

 hf = patch(tpatch,fpatch+.5*3,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORSpatch(2,:);
 hf.FaceAlpha = .6;

%%% method 3 
 
  bl=mean(S.T.I_AXR_I3(:,11));
 norm=mean(S.T.I_AXR_I3(:,1)-bl);
f=(S.T.I_AXR_I3-bl)/norm;
MixingTimelist=S.MixingTimelist;

hl=errorbar(MixingTimelist,mean(f,1)+.5*2,std(f,0,1));
hl.Marker=symbol{1}; hl.LineStyle='none';
hl.Color= [0 0 0];
hl.MarkerFaceColor=COLORSpatch(3,:);

MixingTimeArray=ones(1000,length(S.T.AXR)).*linspace(0,300,1000)';
Imodel=(S.T.I0_I3.*exp(-MixingTimeArray.*S.T.AXR_I3')+S.T.baseline_I3'-bl)/norm;
fmean=mean(Imodel,2);
fstd=std(Imodel,0,2);
plot(MixingTimeArray(:,1),mean(Imodel,2)+.5*2);

fpatch=[fmean+fstd;flipud(fmean-fstd)];
for i=1:length(fpatch)
    if fpatch(i)<1E-10
        fpatch(i)=1E-10;
    end
end
tpatch=[MixingTimeArray(:,1);flipud(MixingTimeArray(:,1))];

 hf = patch(tpatch,fpatch+.5*2,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORSpatch(3,:);
 hf.FaceAlpha = .6;
 
 %%% method 4 
%   bl=mean(S.T.I_AXR_I3(:,11));
%  norm=mean(S.T.I_AXR_I3(:,1)-bl);
f=f(:,1:length(S.MixingTimelist2))
MixingTimelist=S.MixingTimelist2;

hl=errorbar(MixingTimelist,mean(f,1)+.5*1,std(f,0,1));
hl.Marker=symbol{1}; hl.LineStyle='none';
hl.Color= [0 0 0];
hl.MarkerFaceColor=COLORSpatch(4,:);

MixingTimeArray=ones(1000,length(S.T.AXR)).*linspace(0,10,1000)';
Imodel=(S.T.I0_I3_BLsubtract.*exp(-MixingTimeArray.*S.T.AXR_I3_BLsubtract')+S.T.baseline_I3_BLsubtract'-bl)/norm;
fmean=mean(Imodel,2);
fstd=std(Imodel,0,2);
plot(MixingTimeArray(:,1)+.5*1,mean(Imodel,2));

fpatch=[fmean+fstd;flipud(fmean-fstd)];
for i=1:length(fpatch)
    if fpatch(i)<1E-10
        fpatch(i)=1E-10;
    end
end
tpatch=[MixingTimeArray(:,1);flipud(MixingTimeArray(:,1))];

 hf = patch(tpatch,fpatch+.5*1,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORSpatch(4,:);
 hf.FaceAlpha = .6;
 
  %%% method 5 
 
  bl=0 %mean(S.T.I_3(:,11)./exp(-MixingTimelist(11)*S.T.R1_T1app2_2pt(:,1)));
 norm=mean(S.T.I_AXR_I3_rapid(:,1)-bl);
f=(S.T.I_AXR_I3_rapid-bl)/norm;
MixingTimelist=S.MixingTimelist_rapid;

hl=errorbar(MixingTimelist,mean(f,1),std(f,0,1));
hl.Marker=symbol{1}; hl.LineStyle='none';
hl.Color= [0 0 0];
hl.MarkerFaceColor=COLORSpatch(5,:);

MixingTimeArray=ones(1000,length(S.T.AXR)).*linspace(0,10,1000)';
Imodel=(S.T.I0_I3_rapid.*exp(-MixingTimeArray.*S.T.AXR_I3_rapid')+S.T.baseline_I3_rapid'-bl)/norm;
fmean=mean(Imodel,2);
fstd=std(Imodel,0,2);
plot(MixingTimeArray(:,1),mean(Imodel,2));

fpatch=[fmean+fstd;flipud(fmean-fstd)];
for i=1:length(fpatch)
    if fpatch(i)<1E-10
        fpatch(i)=1E-10;
    end
end
tpatch=[MixingTimeArray(:,1);flipud(MixingTimeArray(:,1))];

 hf = patch(tpatch,fpatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORSpatch(5,:);
 hf.FaceAlpha = .6;
 
 %% Plot attenuation and fits, ZOOM
h                   = axes();
h.Units             = 'centimeters';
h.FontName          = FontName;
h.FontSize          = FontSize;
h.FontWeight        = FontWeight;
h.Position          = [1.25 5.5 6 2.5];
%h.YTick             = [.01 .1 1];
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
h.XLabel.String     = '$ t_m$ [ms]';
h.YLabel.String     = '$I/I_0$';
h.YScale            = 'log';

h.XLim(2)           = 20;
h.YLim           = [0.1 10];

h.YLabel.Units      = 'centimeters';
h.YLabel.Position(1) = -0.8;

h.YMinorTick = 'on';
h.XMinorTick = 'on';
h.TickLength = [.02 .02] ;
h.TickDir    = 'out';
h.Box               = 'off';

hold on
symbol={'o','v','^','d','>','s','d'};
COLORS=get(groot,'DefaultAxesColorOrder');

%%% method 1
 bl=mean(S.T.I_AXR(:,11));
 norm=mean(S.T.I_AXR(:,1)-bl)/10^(4/4);
f=(S.T.I_AXR-bl)/norm;
MixingTimelist=S.MixingTimelist;

hl=errorbar(MixingTimelist,mean(f,1),std(f,0,1));
hl.Marker=symbol{1}; hl.LineStyle='none';
hl.Color= [0 0 0];
hl.MarkerFaceColor=COLORSpatch(1,:);

MixingTimeArray=ones(1000,length(S.T.AXR)).*linspace(0,300,1000)';
Imodel=(S.T.I0.*exp(-MixingTimeArray.*S.T.AXR')+S.T.baseline-bl)/norm;
fmean=mean(Imodel,2);
fstd=std(Imodel,0,2);
plot(MixingTimeArray(:,1),mean(Imodel,2));

fpatch=[fmean+fstd;flipud(fmean-fstd)];
for i=1:length(fpatch)
    if fpatch(i)<1E-10
        fpatch(i)=1E-10;
    end
end
tpatch=[MixingTimeArray(:,1);flipud(MixingTimeArray(:,1))];

 hf = patch(tpatch,fpatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORSpatch(1,:);
 hf.FaceAlpha = .6;

 %%% method 2 

 bl=mean(S.T.I3_N24(:,11));
 norm=mean(S.T.I3_N24(:,1)-bl)/10^(3/4);
f=(S.T.I3_N24-bl)/norm;
MixingTimelist=S.MixingTimelist;

hl=errorbar(MixingTimelist,mean(f,1),std(f,0,1));
hl.Marker=symbol{1}; hl.LineStyle='none';
hl.Color= [0 0 0];
hl.MarkerFaceColor=COLORSpatch(2,:);

MixingTimeArray=ones(1000,length(S.T.AXR)).*linspace(0,300,1000)';
Imodel=(S.T.I0_I3_N24.*exp(-MixingTimeArray.*S.T.AXR_I3_N24')+S.T.baseline_I3_N24-bl)/norm;
fmean=mean(Imodel,2);
fstd=std(Imodel,0,2);
plot(MixingTimeArray(:,1),mean(Imodel,2));

fpatch=[fmean+fstd;flipud(fmean-fstd)];
for i=1:length(fpatch)
    if fpatch(i)<1E-10
        fpatch(i)=1E-10;
    end
end
tpatch=[MixingTimeArray(:,1);flipud(MixingTimeArray(:,1))];

 hf = patch(tpatch,fpatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORSpatch(2,:);
 hf.FaceAlpha = .6;

%%% method 3 
 
  bl=mean(S.T.I_AXR_I3(:,11));
 norm=mean(S.T.I_AXR_I3(:,1)-bl)/10^(2/4);
f=(S.T.I_AXR_I3-bl)/norm;
MixingTimelist=S.MixingTimelist;

hl=errorbar(MixingTimelist,mean(f,1),std(f,0,1));
hl.Marker=symbol{1}; hl.LineStyle='none';
hl.Color= [0 0 0];
hl.MarkerFaceColor=COLORSpatch(3,:);

MixingTimeArray=ones(1000,length(S.T.AXR)).*linspace(0,300,1000)';
Imodel=(S.T.I0_I3.*exp(-MixingTimeArray.*S.T.AXR_I3')+S.T.baseline_I3'-bl)/norm;
fmean=mean(Imodel,2);
fstd=std(Imodel,0,2);
plot(MixingTimeArray(:,1),mean(Imodel,2));

fpatch=[fmean+fstd;flipud(fmean-fstd)];
for i=1:length(fpatch)
    if fpatch(i)<1E-10
        fpatch(i)=1E-10;
    end
end
tpatch=[MixingTimeArray(:,1);flipud(MixingTimeArray(:,1))];

 hf = patch(tpatch,fpatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORSpatch(3,:);
 hf.FaceAlpha = .6;
 
 %%% method 4 
%   bl=mean(S.T.I_AXR_I3(:,11));
%  norm=mean(S.T.I_AXR_I3(:,1)-bl);
norm=norm*10^(2/4)/10^(1/4);
f=f(:,1:length(S.MixingTimelist2))/10^(1/4);
MixingTimelist=S.MixingTimelist2;

hl=errorbar(MixingTimelist,mean(f,1),std(f,0,1));
hl.Marker=symbol{1}; hl.LineStyle='none';
hl.Color= [0 0 0];
hl.MarkerFaceColor=COLORSpatch(4,:);

MixingTimeArray=ones(1000,length(S.T.AXR)).*linspace(0,10,1000)';
Imodel=(S.T.I0_I3_BLsubtract.*exp(-MixingTimeArray.*S.T.AXR_I3_BLsubtract')+S.T.baseline_I3_BLsubtract'-bl)/norm;
fmean=mean(Imodel,2);
fstd=std(Imodel,0,2);
plot(MixingTimeArray(:,1),mean(Imodel,2));

fpatch=[fmean+fstd;flipud(fmean-fstd)];
for i=1:length(fpatch)
    if fpatch(i)<1E-10
        fpatch(i)=1E-10;
    end
end
tpatch=[MixingTimeArray(:,1);flipud(MixingTimeArray(:,1))];

 hf = patch(tpatch,fpatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORSpatch(4,:);
 hf.FaceAlpha = .6;
 
  %%% method 5 
 
  bl=0 %mean(S.T.I_3(:,11)./exp(-MixingTimelist(11)*S.T.R1_T1app2_2pt(:,1)));
 norm=mean(S.T.I_AXR_I3_rapid(:,1)-bl);
f=(S.T.I_AXR_I3_rapid-bl)/norm;
MixingTimelist=S.MixingTimelist_rapid;

hl=errorbar(MixingTimelist,mean(f,1),std(f,0,1));
hl.Marker=symbol{1}; hl.LineStyle='none';
hl.Color= [0 0 0];
hl.MarkerFaceColor=COLORSpatch(5,:);

MixingTimeArray=ones(1000,length(S.T.AXR)).*linspace(0,10,1000)';
Imodel=(S.T.I0_I3_rapid.*exp(-MixingTimeArray.*S.T.AXR_I3_rapid')+S.T.baseline_I3_rapid'-bl)/norm;
fmean=mean(Imodel,2);
fstd=std(Imodel,0,2);
plot(MixingTimeArray(:,1),mean(Imodel,2));

fpatch=[fmean+fstd;flipud(fmean-fstd)];
for i=1:length(fpatch)
    if fpatch(i)<1E-10
        fpatch(i)=1E-10;
    end
end
tpatch=[MixingTimeArray(:,1);flipud(MixingTimeArray(:,1))];

 hf = patch(tpatch,fpatch,'w');
 hf.LineStyle = 'none';
 hf.FaceColor = COLORSpatch(5,:);
 hf.FaceAlpha = .6;
%% BoxPlot


h                   = axes();
h.Units             = 'centimeters';
h.FontName          = FontName;
h.FontSize          = FontSize;
h.FontWeight        = FontWeight;
h.Position          = [1.25 1.25 6 3.25];
%h.YTick             = [.001 .01 .1 1];
h.XTick             = [1:5];
h.XTickLabel             = {'1' '2' '3' '4' '5'};
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
h.XLabel.String     = 'Method ';
h.YLabel.String     = '$\mathrm{AXR}$ [$\mathrm{s^{-1}}$]';
%h.YScale            = 'log';
 h.XLim(2)           = 6;
% h.YLim(1)           = 1e-3;
 h.YLim(2)           = 160;

h.YLabel.Units      = 'centimeters';
h.YLabel.Position(1) = -0.8;
h.YGrid = 'on';
% 
% h.YMinorTick = 'on';
% h.XMinorTick = 'on';
% h.TickLength = [.02 .02] ;
% h.TickDir    = 'out';
% h.Box               = 'off';

hold on

h=violin(AXRarray*1000,'x',x,'facecolor',[COLORSpatch]);

h=boxplot2(AXRarray*1000,x,'barwidth',0.5,'notch','on');

 h = findobj(gca,'Tag','Box');
 for j=1:length(h)/5
    
    hf=patch(get(h(j*5),'XData'),get(h(j*5),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(1,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-1),'XData'),get(h(j*5-1),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(2,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-2),'XData'),get(h(j*5-2),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(3,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-3),'XData'),get(h(j*5-3),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(4,:);
    %hf.FaceAlpha = .6;
    
    hf=patch(get(h(j*5-4),'XData'),get(h(j*5-4),'YData'),'w');
    hf.LineStyle = 'none';
    hf.FaceColor = COLORSpatch(5,:);
    %hf.FaceAlpha = .6;
 end
 h=boxplot2(AXRarray*1000,x,'barwidth',0.5,'notch','on');
%%
% figure
% h=boxplot2(slopeb13array,x);
quartiles = quantile(AXRarray*1000,[0.25, 0.5, 0.75])
IQR=quartiles(3,:)-quartiles(1,:)
 %% Save figure.
 fig.Renderer='Painters';

 %% Save figure.
print(fig,'williamson_fig_AXR_repeats_violin.eps','-depsc')
print(fig,'williamson_fig_AXR_repeats_violin.png','-dpng','-r2048')
%print(fig,'williamson_figure_1Ddiff_normal_bw.eps','-deps')
print(fig,'williamson_fig_AXR_repeats_violin.tif','-dtiff','-r2048')

