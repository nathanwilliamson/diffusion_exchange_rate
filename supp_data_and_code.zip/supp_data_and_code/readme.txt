Readme file for supplementary material submitted with Williamson et al., Real-time measurement of diffusion exchange rate in biological tissue, Journal of Magnetic Resonance (2020)

This folder contains the necessary data and code to re-create figures in the results section using MATLAB 2019b. Data is contained within MATLAB structures (struct) named ’S’ within the .m files. Figures 6, 8 and 9 require the following publicly available packages:

NMR_Decay_Analysis (Nathan Williamson and Magnus Röding 2017 https://github.com/nathanwilliamson/NMR_decay_analysis) *the necessary code is contained within the folder “diffusion_semiparametric”. This folder must be added to the Matlab path

boxplot2 (Kelly Kearney (2020). boxplot2 (https://www.github.com/kakearney/boxplot2-pkg), GitHub. Retrieved June 22, 2020. )

violin (Holger Hoffmann (2020). Violin Plot (https://www.mathworks.com/matlabcentral/fileexchange/45134-violin-plot), MATLAB Central File Exchange. Retrieved June 22, 2020. )

