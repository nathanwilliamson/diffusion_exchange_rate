%close all
clear all
set(groot,'defaulttextinterpreter','latex');  
set(groot, 'defaultAxesTickLabelInterpreter','latex');  
set(groot, 'defaultLegendInterpreter','latex');

%% load and prepare data


load('Magnevist0pt5mM_20200211_DEXSY.mat')

%% Initialize figure.

COLORS = 1/255 * [  55  80  162 ; ...
    93  187 70  ; ...
    241 156 31  ; ...
    237 28  36  ; ...
    129 41  134 ];
COLORSpatch = 1/255 * [255 255 100  ; ...
    100 255 100  ; ...
    150 255 255];

col=get(groot,'DefaultAxesColorOrder');
fig                 = figure();
fig.Units           = 'centimeters';
fig.PaperUnits      = 'centimeters';
fig.Position        = [0 0 8 4];
fig.PaperPosition   = fig.Position;



FontName            = 'helvetica';
FontSize            = 7;
FontWeight          = 'normal';

 
%% Plot attenuation and fits
h                   = axes();
h.Units             = 'centimeters';
h.FontName          = FontName;
h.FontSize          = FontSize;
h.FontWeight        = FontWeight;
h.Position          = [1.25 1.25 6 2.5];
h.YTick             = [.01 .1 1];
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
%h.XLabel.String     = '$ b\ \mathrm{ (\times 10^{3}\ s/mm^2)  } $';
h.XLabel.String     = '$ t_m$ [ms]';
h.YLabel.String     = '$I/I_0$';
h.YScale            = 'log';
h.XLim(2)           = 1000;
h.YLim           = [.001 1];

h.YLabel.Units      = 'centimeters';
h.YLabel.Position(1) = -0.8;

h.YMinorTick = 'on';
h.XMinorTick = 'on';
h.TickLength = [.02 .02] ;
h.TickDir    = 'out';
h.Box               = 'off';

hold on

%% I_1
MixingTimelist=S.MixingTimelist';
Imean=mean(S.T.I_1,1)';
Istd=std(S.T.I_1,0,1)';
Imean=Imean/mean(S.T.I0_T1app1);
% Imean=Imean/mean(S.T.I_1(:,1));
% Istd=Istd/mean(S.T.I_1(:,1));

Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end
bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(1,:);
%  hf.FaceAlpha = .5;

hl1 = line(MixingTimelist,Imean);%/Imean(1)
% hl.LineStyle = 'none';
 hl1.Marker = 'o';
  hl1.LineStyle = 'none';
  hl1.MarkerFaceColor=COLORS(1,:);
 hl1.MarkerSize = 6;
 hl1.Color = [0.8 0.8 0.8];
 hl1.DisplayName='$I_{pt1}$'

theory=exp(-MixingTimelist*mean(S.T.AXR_T1app1));
%theory=theory/mean(S.T.I_1(:,1))
hl = line(MixingTimelist,theory);%/Imean(1)
 hl.LineStyle = '-';
 hl.Color = [0 0 0];


 %% I_2

Imean=mean(S.T.I_2,1)';
Istd=std(S.T.I_2,0,1)';
Imean=Imean/mean(S.T.I_1(:,1));
Istd=Istd/mean(S.T.I_1(:,1));
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(5,:);
%  hf.FaceAlpha = .6;

hl = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl.Marker = 'o';
hl.MarkerFaceColor=COLORS(5,:);
   hl.LineStyle = 'none';
 hl.MarkerSize = 3;
 hl.Color = [0 0 0];
 
%  theory=mean(S.T.I0_T1app2)*exp(-MixingTimelist*mean(S.T.AXR_T1app2));
% theory=theory/mean(S.T.I_1(:,1))
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];
 
 %% I_3

Imean=mean(S.T.I_3,1)';
Istd=std(S.T.I_3,0,1)';
Imean=Imean/mean(S.T.I_1(:,1));
Istd=Istd/mean(S.T.I_1(:,1));
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(3,:);
%  hf.FaceAlpha = .6;

hl = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl.Marker = 'o';
hl.MarkerFaceColor=COLORS(3,:);
   hl.LineStyle = 'none';
 hl.MarkerSize = 3;
 hl.Color = [0.3 0.3 0.3];
 
%  load('SpinalCord_Fixed_20181214_tmMin100Max1000.mat')
%  MixingTimelist=S.MixingTimelist';
% 
%  theory=mean(S.T.I0_T1app3)*exp(-MixingTimelist*mean(S.T.AXR_T1app3)) *exp(-MixingTimelist(1)*mean(S.T.AXR_T1app3));
% theory=theory/mean(S.T.I_1(:,1))
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];
%  
% load('SpinalCord_Fixed_20181214_tmMax1000.mat')
%  MixingTimelist=S.MixingTimelist';

  %% I_4

Imean=mean(S.T.I_4,1)';
Istd=std(S.T.I_4,0,1)';
Imean=Imean/mean(S.T.I_1(:,1));
Istd=Istd/mean(S.T.I_1(:,1));
Ipatch=[Imean+Istd;flipud(Imean-Istd)];
for i=1:length(Ipatch)
    if Ipatch(i)<1E-10
        Ipatch(i)=1E-10;
    end
end

bpatch=[MixingTimelist;flipud(MixingTimelist)];

%  hf = patch(bpatch,Ipatch,'w');
%  hf.LineStyle = 'none';
%  hf.FaceColor = COLORS(4,:);
%  hf.FaceAlpha = .6;

hl = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
hl.Marker = 'o';
hl.MarkerFaceColor=COLORS(4,:);
hl.LineStyle = 'none';
hl.MarkerSize = 3;
hl.Color = [0.7 0.7 0.7];

 
%  theory=mean(S.T.I0_T1app4)*exp(-MixingTimelist*mean(S.T.AXR_T1app4));
% theory=theory/mean(S.T.I_1(:,1))
% hl = line(MixingTimelist,theory);%/Imean(1)
%  hl.LineStyle = '-';
%  hl.Color = [0 0 0];
% 
%  

%fig.Renderer='painters';
%% T1 sat reco
%Norm=mean(S.T.I_1(:,1));
load('Magnevist0pt5mM_20200211_T1satreco.mat')
MixingTimelist=S.MixingTimelist*1000;
Imean=mean(S.T.I,1);
Imean=mean(S.T.I0)-mean(S.T.baseline)-Imean;
Imean=Imean/(mean(S.T.I0)-mean(S.T.baseline));

hl2 = line(MixingTimelist,Imean);
% hl.LineStyle = 'none';
 hl2.Marker = 's';
hl2.MarkerFaceColor=COLORS(4,:);
 hl2.LineStyle = 'none';
 hl2.MarkerSize = 3;
 hl2.Color = [1 1 1];
 hl2.DisplayName='$T_1$ signal'
 
 legend([hl1 hl2],'Box','off')
%   theory=exp(-MixingTimelist/1000*mean(S.T.R1));
%  %theory=theory/mean(S.T.I_1(:,1))
%  hl = line(MixingTimelist,theory);%/Imean(1)
%   hl.LineStyle = '-';
%  hl.Color =COLORS(4,:);


%% Save figure.
print(fig,'williamson_fig1.eps','-depsc')
print(fig,'williamson_fig1.png','-dpng')
%print(fig,'williamson_figure_1Ddiff_normal_bw.eps','-deps')
print(fig,'williamson_fig1.tif','-dtiff','-r300')
%plot2svg('williamson_figure_1Ddiff_7C.svg');


